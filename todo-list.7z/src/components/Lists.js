import React from 'react'
import  "./TodoList.css";

const Lists = (props) => {

   
    return  (
    <div>
        <div className="todo_style">
            
            <li> { props.text} </li> <i className="fa fa-times text-danger" onClick={ () => {
                props.onSelect(props.id);
            } }></i>
        </div>
    </div>
    )
};

export default Lists;
