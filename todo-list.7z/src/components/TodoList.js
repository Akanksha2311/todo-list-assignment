import React, { useState } from 'react'
import Lists from './Lists';
import './TodoList.css';

export default function TodoList() {

    const [inputList , setInputList ] = useState("");
    const [items, setItems] = useState([]);

    const todoItem = (event) => {
        setInputList(event.target.value);
    };

    const listOfItems = () => {
        setItems( (oldItems) => {
            return [...oldItems , inputList];
        } );
        setInputList("");
    };

    const deleteItems = (id) => {
        console.log('deleted');
        setItems ( (oldItems) => {
            return oldItems.filter((arrElement , index) => {
                return index !== id;
            })
        } )
    }

    return (
        <div>
            <div className="first_div">
                <div className="list">
                    <br/>
                    <h1>TODO LIST</h1>
                    <br/>
                    <input type="text" placeholder="Add a item." onChange={todoItem} value={inputList} />
                    <button className=" btn text-success fa fa-plus" onClick={listOfItems}></button>

                    <ol>
                        { items.map( (itemval , index) => {
                              return  <Lists  key={index} id={index} text={itemval} onSelect={deleteItems} />
                            } )}      
                    </ol>   
                </div>
            </div>
        </div>
    )
}
